package com.ht.season.food;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository("foodDAO")
public class foodDAOImpl implements foodDAO {
	
	
	@Inject
	private SqlSession sqlSession;
	@Override
	public List<foodDTO> viewFood(foodDTO vo) {
		return sqlSession.selectList("food.viewFood", vo);
	}
	
	@Override
	public void create(foodDTO dto) {
		
	}
	@Override
	public void foodcreate(String name,String life,String country,String price,String unit) throws Exception {
		Map<String,Object> map = new HashMap<>();
		System.out.println("찍히나 테스트");
		map.put("name",name);
		map.put("life",life);
		map.put("country",country);
		map.put("price",price);
		map.put("unit",unit);
		System.out.println(name+life+country+price+unit);
		sqlSession.insert("food.insert",map);
		/* sqlSession.insert("food.insertStock",dto); */
	}
	
	public void foodinsert(ArrayList<Object> list) throws Exception {
		Map<String,Object> map = new HashMap<>();
		
		System.out.println("찍히나 테스트");
		map.put("name",list.get(0).toString());
		map.put("life",list.get(1).toString());
		map.put("country",list.get(2).toString());
		map.put("price",list.get(3).toString());
		map.put("unit",list.get(4).toString());
		sqlSession.insert("food.foodinsert",map);
		System.out.println(list);
	}
	
	
	

}
