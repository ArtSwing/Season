package com.ht.season;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ht.season.food.foodDAO;
import com.ht.season.food.foodDAOImpl;
import com.ht.season.food.foodDTO;
import com.ht.season.food.foodService;

@Controller
public class FoodController {
	@Inject
	foodService fd;
	
	@Inject
	foodDAOImpl fooddaoimpl;

	@RequestMapping("/food")
	public ModelAndView food(@ModelAttribute foodDTO vo) {
		List<foodDTO> vo2 = fd.viewFood(vo);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("foodList");
		mav.addObject("list", vo2);
		return mav;
	}

	@RequestMapping("/insertFood")
	public ModelAndView foodinsert(HttpServletRequest req, @ModelAttribute foodDTO vo) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("foodInsert");
		return mav;
		
	
	}
	
	@RequestMapping("/foodAction")
	public String foodAction(HttpServletRequest req) throws Exception {
		if(req.getParameter("name") != null) {
			
		String name = req.getParameter("name");
		String life = req.getParameter("life");
		String country = req.getParameter("country");
		String price = req.getParameter("price");
		String unit= req.getParameter("unit");
		fooddaoimpl.foodcreate(name, life, country, price, unit);
		}
		return "foodAction";
		
	}

	@RequestMapping("/excelImport")
	public String excelImport(HttpServletRequest req, MultipartFile files) {
		System.out.println("Excel file Import");
		try {
			File convFile = new File(files.getOriginalFilename());
			files.transferTo(convFile);
			File file = convFile;
			
			Workbook wb = WorkbookFactory.create(file);
			Sheet sheet = wb.getSheetAt(0);
			Iterator<Row> iterator = sheet.iterator();
			ArrayList<Object> list = new ArrayList<Object>();
			int cnt =0;
			while (iterator.hasNext()) {
				Row currentRow = iterator.next();
				Iterator<Cell> cellIterator = currentRow.iterator();
				
				while(cellIterator.hasNext()) {
				Cell currentCell = cellIterator.next();
				
				if (currentCell.getCellType() == CellType.STRING) {
					System.out.println(currentCell.getStringCellValue());
					list.add(cnt,currentCell.getStringCellValue());
				} else if (currentCell.getCellType() == CellType.NUMERIC) {
					System.out.println(currentCell.getNumericCellValue());
					list.add(cnt, (int) currentCell.getNumericCellValue());
				}
				cnt ++;
				if (cnt ==5) {
					System.out.println(list.subList(0, cnt));
					fooddaoimpl.foodinsert(list);
					cnt = 0;
					
				}
			}
			System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:food";
	}

	@RequestMapping(value = "insertFoodOK", method = RequestMethod.POST)
	public String insert(@ModelAttribute foodDTO dto) throws Exception {
		fd.create(dto);
		return "redirect:food";
	}

}
