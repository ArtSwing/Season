package com.ht.season.chart;

import java.util.List;


public interface chartService {
	public List<chartDTO> viewChart(chartDTO vo);
	

}
