package com.ht.season.food;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface foodDAO {
	public List<foodDTO> viewFood(foodDTO vo);
	public void foodcreate(String name,String life,String country,String price,String unit) throws Exception;
	public static void foodinsert(ArrayList<Object> list) throws Exception {
		// TODO Auto-generated method stub
		
	}
	public void create(foodDTO dto);
}
