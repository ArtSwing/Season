package com.ht.season.chart;

import java.sql.Date;

public class chartDTO {

	
	public String getChid() {
		return chid;
	}
	public void setChid(String chid) {
		this.chid = chid;
	}
	public String getMincome() {
		return mincome;
	}
	public void setMincome(String mincome) {
		this.mincome = mincome;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMday() {
		return mday;
	}
	public void setMday(String mday) {
		this.mday = mday;
	}
	public String getSale() {
		return sale;
	}
	public void setSale(String sale) {
		this.sale = sale;
	}
	public String getSpot() {
		return spot;
	}
	public void setSpot(String spot) {
		this.spot = spot;
	}
	public String getSday() {
		return sday;
	}
	public void setSday(String sday) {
		this.sday = sday;
	}
	public String getEday() {
		return eday;
	}
	public void setEday(String eday) {
		this.eday = eday;
	}
	@Override
	public String toString() {
		return "chartDTO [chid=" + chid + ", mincome=" + mincome + ", mid=" + mid + ", mday=" + mday + ", sale=" + sale
				+ ", spot=" + spot + ", sday=" + sday + ", eday=" + eday + "]";
	}
	private String chid;
	private String mincome;
	private String mid;
	private String mday;
	private String sale;
	private String spot;
	private String sday;
	private String eday;
	

}
