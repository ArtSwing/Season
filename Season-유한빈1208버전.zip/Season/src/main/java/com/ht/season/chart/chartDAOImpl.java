package com.ht.season.chart;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository("chartDAO")
public class chartDAOImpl implements chartDAO {
	@Inject
	private SqlSession sqlSession;
	
	@Override
	public List<chartDTO> viewChart(chartDTO vo) {
		return sqlSession.selectList("chart.chartView",vo);
	}

}
