package com.ht.season.chart;

import java.util.List;


public interface chartDAO {

	public List<chartDTO> viewChart(chartDTO vo);

}
