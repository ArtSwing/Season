package com.ht.season;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ht.season.chart.chartDTO;
import com.ht.season.chart.chartService;

@Controller
public class chartController {
	@Inject
	chartService cs;

	@RequestMapping(value = "chart", method = RequestMethod.GET)
	public ModelAndView chart(@RequestParam(required = false, defaultValue = "10") String month,
			@RequestParam(required = false, defaultValue = "2019") String year, @ModelAttribute chartDTO vo) {

		Calendar calendar = Calendar.getInstance();
		int MM = Integer.parseInt(month) - 1;
		calendar.set(Integer.parseInt(year), MM, 1);
		int startDay = calendar.getActualMinimum(Calendar.DAY_OF_MONTH);
		int endDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

		String start = year + "-" + month + "-" + startDay;
		String end = year + "-" + month + "-" + endDay;
		vo.setSday(start);
		vo.setEday(end);
		System.out.println(start);
		System.out.println(end);

		List<chartDTO> vo1 = cs.viewChart(vo); // listAll() 과 같음

		ModelAndView mav = new ModelAndView();

		mav.setViewName("chartView"); // 뷰를 chartView.jsp로 설정
		mav.addObject("ch", vo1);
		return mav;
	}

}